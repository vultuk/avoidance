package com.avoidance.avoidance_game

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
